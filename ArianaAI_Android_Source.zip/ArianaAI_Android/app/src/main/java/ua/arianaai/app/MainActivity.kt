package ua.arianaai.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var chat: LinearLayout
    private lateinit var input: EditText
    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private val prefs by lazy { getSharedPreferences("ariana_chat", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildScreen()
        restoreMessages()
    }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 18, 20, 14)
            setBackgroundColor(0xFFFFF7FA.toInt())
        }
        val title = TextView(this).apply {
            text = "Ариана"
            textSize = 28f
            setTextColor(0xFF7B3158.toInt())
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Особистий AI-компаньйон • рання версія"
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(0xFF795D6B.toInt())
        }
        chat = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(4, 14, 4, 14)
        }
        val scroll = ScrollView(this).apply {
            addView(chat)
        }
        input = EditText(this).apply {
            hint = "Напиши Аріані…"
            textSize = 16f
            setSingleLine(false)
            minLines = 1
            maxLines = 4
        }
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val mic = Button(this).apply {
            text = "🎙"
            contentDescription = "Голосове введення"
            setOnClickListener { startVoiceInput() }
        }
        val send = Button(this).apply {
            text = "Надіслати"
            setOnClickListener { sendMessage() }
        }
        controls.addView(mic, LinearLayout.LayoutParams(58, -2))
        controls.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        controls.addView(send)
        page.addView(title)
        page.addView(subtitle)
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        page.addView(controls)
        setContentView(page)
    }

    private fun addBubble(text: String, fromUser: Boolean) {
        val bubble = TextView(this).apply {
            this.text = text
            textSize = 16f
            setTextColor(0xFF30252B.toInt())
            setPadding(14, 10, 14, 10)
            setBackgroundColor(if (fromUser) 0xFFFFDCEB.toInt() else 0xFFFFFFFF.toInt())
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = if (fromUser) Gravity.END else Gravity.START
            setPadding(0, 5, 0, 5)
            addView(bubble, LinearLayout.LayoutParams(-2, -2).apply {
                width = (resources.displayMetrics.widthPixels * 0.78f).toInt()
            })
        }
        chat.addView(row)
    }

    private fun sendMessage() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        addBubble(text, true)
        saveLine("Ти: $text")
        input.setText("")
        val reply = "Я отримала твоє повідомлення. Зараз це початкова версія інтерфейсу: підключення локальної мовної моделі ще потрібно реалізувати."
        addBubble(reply, false)
        saveLine("Аріана: $reply")
        if (ttsReady) tts.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "ariana_reply")
    }

    private fun saveLine(line: String) {
        val old = prefs.getString("history", "") ?: ""
        prefs.edit().putString("history", (old + line + "\n").takeLast(24000)).apply()
    }

    private fun restoreMessages() {
        val history = prefs.getString("history", "") ?: return
        history.lineSequence().filter { it.isNotBlank() }.forEach { line ->
            val user = line.startsWith("Ти:")
            addBubble(line.substringAfter(": ").ifEmpty { line }, user)
        }
    }

    private fun startVoiceInput() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "На телефоні немає доступного розпізнавання мовлення", Toast.LENGTH_LONG).show()
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 41)
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "uk-UA")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Говори українською")
        }
        try {
            startActivityForResult(intent, 42)
        } catch (_: Exception) {
            Toast.makeText(this, "Не вдалося запустити голосове введення", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated by Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 42 && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) {
                input.setText(spoken)
                input.setSelection(input.text.length)
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            startVoiceInput()
        } else if (requestCode == 41) {
            Toast.makeText(this, "Для голосового введення потрібен дозвіл на мікрофон", Toast.LENGTH_LONG).show()
        }
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) {
            val result = tts.setLanguage(Locale.forLanguageTag("uk-UA"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                ttsReady = false
            }
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }
}
