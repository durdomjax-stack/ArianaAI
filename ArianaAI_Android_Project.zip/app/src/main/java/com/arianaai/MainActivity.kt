package com.arianaai
import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.*
import android.graphics.Typeface
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
 private lateinit var tts: TextToSpeech
 private lateinit var chat: LinearLayout
 private lateinit var input: EditText
 private val prefs by lazy { getSharedPreferences("ariana_memory", MODE_PRIVATE) }
 private val history = mutableListOf<String>()
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState); tts=TextToSpeech(this,this)
  val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(24,28,24,18); setBackgroundColor(0xFFFFF4F7.toInt()) }
  val title=TextView(this).apply { text="Ariana"; textSize=30f; setTypeface(null,Typeface.BOLD); setTextColor(0xFF9C4267.toInt()) }
  val sub=TextView(this).apply { text="Твоя особиста AI-співрозмовниця"; textSize=14f }
  chat=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
  val scroll=ScrollView(this).apply { addView(chat) }
  input=EditText(this).apply { hint="Напиши Аріані..." }
  val actions=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
  actions.addView(Button(this).apply { text="Надіслати"; setOnClickListener { sendMessage() } },LinearLayout.LayoutParams(0,-2,1f))
  actions.addView(Button(this).apply { text="🎙"; setOnClickListener { startVoiceInput() } })
  root.addView(title); root.addView(sub); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f)); root.addView(input); root.addView(actions); setContentView(root)
  prefs.getString("history","")?.lines()?.filter { it.isNotBlank() }?.takeLast(30)?.forEach { addLine(it) }
  if(chat.childCount==0) addLine("Аріана: Привіт ❤️ Це початкова версія. Локальну модель ще потрібно під'єднати.")
 }
 private fun sendMessage() {
  val msg=input.text.toString().trim(); if(msg.isEmpty()) return
  addLine("Ти: $msg"); input.text.clear()
  val reply="Я почула тебе. Для повноцінної відповіді потрібно під'єднати локальну мовну модель Gemma."
  addLine("Аріана: $reply"); tts.speak(reply,TextToSpeech.QUEUE_FLUSH,null,"ariana_reply")
  prefs.edit().putString("history",history.takeLast(60).joinToString("\n")).apply()
 }
 private fun addLine(s:String) { history.add(s); chat.addView(TextView(this).apply { text=s; textSize=16f; setTextColor(0xFF292329.toInt()); setPadding(8,12,8,12) }) }
 private fun startVoiceInput() {
  val i=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply { putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); putExtra(RecognizerIntent.EXTRA_LANGUAGE,"uk-UA"); putExtra(RecognizerIntent.EXTRA_PROMPT,"Говори з Аріаною") }
  try { startActivityForResult(i,42) } catch (_:Exception) { Toast.makeText(this,"Голосове введення недоступне",Toast.LENGTH_LONG).show() }
 }
 override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) { super.onActivityResult(requestCode,resultCode,data); if(requestCode==42 && resultCode==RESULT_OK) { input.setText(data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()); sendMessage() } }
 override fun onInit(status:Int) { if(status==TextToSpeech.SUCCESS) tts.language=Locale("uk","UA") }
 override fun onDestroy() { if(::tts.isInitialized) tts.shutdown(); super.onDestroy() }
}
